#!/usr/bin/env python3
"""Validate a merged HaloFPX wiki against the prompt-package section registry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

REQUIRED_FILES = (
    "README.md",
    "facts_and_constraints.md",
    "design_implications.md",
    "procedures_and_checks.md",
    "open_questions.md",
    "sources.md",
    "section.yaml",
)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("wiki_root", type=Path, help="Path to the assembled HaloFPX_Wiki directory")
    parser.add_argument(
        "--registry",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "section_index.json",
        help="Path to section_index.json",
    )
    parser.add_argument("--show-complete", action="store_true")
    args = parser.parse_args()

    try:
        registry = json.loads(args.registry.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot read registry: {exc}", file=sys.stderr)
        return 2

    missing_sections = []
    incomplete = []
    complete = []

    for item in registry:
        section_path = args.wiki_root / item["target_path"]
        if not section_path.is_dir():
            missing_sections.append(item)
            continue
        missing_files = [name for name in REQUIRED_FILES if not (section_path / name).is_file()]
        if missing_files:
            incomplete.append((item, missing_files))
        else:
            complete.append(item)

    print(f"Wiki root: {args.wiki_root}")
    print(f"Expected sections: {len(registry)}")
    print(f"Complete: {len(complete)}")
    print(f"Incomplete: {len(incomplete)}")
    print(f"Missing: {len(missing_sections)}")

    if args.show_complete:
        for item in complete:
            print(f"OK {item['section_id']} {item['title']}")

    for item, files in incomplete:
        print(f"INCOMPLETE {item['section_id']} {item['target_path']}: missing {', '.join(files)}")
    for item in missing_sections:
        print(f"MISSING {item['section_id']} {item['target_path']}")

    return 1 if incomplete or missing_sections else 0

if __name__ == "__main__":
    raise SystemExit(main())
