#
# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# See LICENSE.txt for more license information
#

##### version
NCCL_MAJOR   := 2
NCCL_MINOR   := 30
NCCL_PATCH   := 4
NCCL_SUFFIX  :=
PKG_REVISION := 1
