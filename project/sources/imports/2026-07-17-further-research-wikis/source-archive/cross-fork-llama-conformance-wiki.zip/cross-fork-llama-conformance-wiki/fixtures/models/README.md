# Model fixtures

Model binaries are intentionally **not** embedded in this folder. Every executable run must resolve a model ID to a local file whose SHA-256 matches an approved manifest entry.

The one concrete download pin is the tiny Stories Q4_0 fixture already pinned by the researched upstream CMake tests. All other model choices remain unset until the program owners complete licensing, architecture, and hardware-lane selection. This prevents a plausible-looking model name or digest from becoming an accidental oracle.

Use `scripts/build-fixture-manifest.py` to hash local materializations. The resulting lock file is an input to reference promotion and every conformance run.
